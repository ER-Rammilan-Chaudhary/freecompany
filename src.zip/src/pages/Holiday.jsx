export default function Holiday() {
    return (
      <div className="page-box">
        <h2>Holiday Page</h2>
        <p>Company holiday list.</p>
      </div>
    );
  }
  