export default function Leave() {
    return (
      <div className="page-box">
        <h2>Leave Page</h2>
        <p>Apply or check leave status.</p>
      </div>
    );
  }
  