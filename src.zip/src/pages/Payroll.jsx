export default function Payroll() {
    return (
      <div className="page-box">
        <h2>Payroll Page</h2>
        <p>Your salary details & payslips.</p>
      </div>
    );
  }
  