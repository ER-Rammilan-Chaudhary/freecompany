import logo from "./logo.svg";
import mailIcon from "./mail_icon.svg";
import notification from "./notification.png";
import profile from "./profile.svg";
import holidays from "./holidays.svg";
import attendance from "./attendance.svg";
import leave from "./leave.svg";
import payroll from "./payroll.svg";
import my_desktop from "./my_desktop.svg";
import profile_icon from "./profile_icon.jpg";

export {
  logo,
  mailIcon,
  notification,
  profile,
  holidays,
  attendance,
  leave,
  payroll,
  my_desktop,
  profile_icon,





};
